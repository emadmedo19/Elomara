import { ChatMessage, GeminiModel } from '../types';
import { getStoredSettings } from './storage';

export interface GeminiChatOptions {
  messages: ChatMessage[];
  model?: GeminiModel;
  systemInstruction?: string;
}

export interface GeminiReceiptOcrResult {
  vendor: string;
  amount: number;
  category: 'مصاعد' | 'كهرباء' | 'مياه ومضخات' | 'نظافة' | 'أمن وبوابين' | 'صيانة عامة' | 'أخرى';
  date: string;
  notes: string;
}

// Map models to valid model aliases
const MODEL_MAP: Record<GeminiModel, string> = {
  'gemini-3.8-flash': 'gemini-3.8-flash',
  'gemini-3.1-flash-lite': 'gemini-3.1-flash-lite',
  'gemini-4-argon': 'gemini-4-argon',
};

// Fallback hosted URL for standalone Android APK if relative path is unreachable
const HOSTED_BACKEND_FALLBACK = 'https://ais-dev-yoelyzafiuxqmyed6eui2x-191911353146.europe-west1.run.app';

/**
 * Determine the backend base URL.
 * In browser: uses relative '' (same origin).
 * In Android Capacitor WebView: uses configured backendUrl or the hosted server.
 */
function getBackendBaseUrl(): string {
  const settings = getStoredSettings();
  if (settings.backendUrl && settings.backendUrl.trim()) {
    return settings.backendUrl.trim().replace(/\/+$/, '');
  }

  // If in web browser, relative path works
  if (typeof window !== 'undefined' && window.location.protocol.startsWith('http')) {
    // If running in development or hosted domain
    if (window.location.hostname !== 'localhost' || window.location.port === '3000') {
      return '';
    }
  }

  return HOSTED_BACKEND_FALLBACK;
}

/**
 * Send chat messages directly and securely to the backend Gemini service.
 * The server securely holds the GEMINI_API_KEY without exposing it to the client.
 */
export async function sendGeminiChatMessage(options: GeminiChatOptions): Promise<string> {
  const { messages, model = 'gemini-3.8-flash', systemInstruction } = options;
  const targetModel = MODEL_MAP[model] || 'gemini-3.8-flash';

  const historyPayload = messages.map((m) => ({
    role: m.role,
    text: m.text,
  }));

  const payload = JSON.stringify({
    messages: historyPayload,
    model: targetModel,
    systemInstruction,
  });

  const base = getBackendBaseUrl();
  const primaryEndpoint = `${base}/api/gemini/chat`;

  try {
    const response = await fetch(primaryEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
    });

    if (response.ok) {
      const data = await response.json();
      if (data.text) {
        return data.text;
      }
    }

    const errJson = await response.json().catch(() => null);
    throw new Error(errJson?.error || `خطأ في استجابة الخادم (${response.status})`);
  } catch (error: any) {
    // If relative fetch failed and base wasn't the hosted fallback, try the hosted fallback
    if (base !== HOSTED_BACKEND_FALLBACK) {
      try {
        const fallbackResponse = await fetch(`${HOSTED_BACKEND_FALLBACK}/api/gemini/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: payload,
        });
        if (fallbackResponse.ok) {
          const fbData = await fallbackResponse.json();
          if (fbData.text) return fbData.text;
        }
      } catch {
        // Fall through to standard error handling
      }
    }

    if (!navigator.onLine || error.message.includes('Failed to fetch')) {
      throw new Error('تعذر الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت في هاتفك والمحاولة مجدداً.');
    }

    throw new Error(`تعذر معالجة الطلب: ${error.message || 'خطأ غير معروف'}`);
  }
}

/**
 * Scan receipt via Gemini OCR through the secure backend
 */
export async function analyzeReceiptWithGemini(
  base64Image: string,
  mimeType: string = 'image/jpeg'
): Promise<GeminiReceiptOcrResult> {
  const cleanBase64 = base64Image.replace(/^data:image\/[a-zA-Z0-9]+;base64,/, '');
  const base = getBackendBaseUrl();
  const endpoint = `${base}/api/gemini/analyze-receipt`;

  const body = JSON.stringify({ base64Image: cleanBase64, mimeType });

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
    });

    if (res.ok) {
      const data = await res.json();
      return {
        vendor: data.vendor || 'مورد محلي',
        amount: Number(data.amount) || 0,
        category: data.category || 'صيانة عامة',
        date: data.date || new Date().toISOString().split('T')[0],
        notes: data.notes || 'فاتورة صيانة',
      };
    }

    throw new Error('تعذر قراءة الفاتورة عبر الخادم');
  } catch (err: any) {
    // Try hosted fallback if relative failed
    if (base !== HOSTED_BACKEND_FALLBACK) {
      const fbRes = await fetch(`${HOSTED_BACKEND_FALLBACK}/api/gemini/analyze-receipt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
      }).catch(() => null);

      if (fbRes && fbRes.ok) {
        const data = await fbRes.json();
        return {
          vendor: data.vendor || 'مورد محلي',
          amount: Number(data.amount) || 0,
          category: data.category || 'صيانة عامة',
          date: data.date || new Date().toISOString().split('T')[0],
          notes: data.notes || 'فاتورة صيانة',
        };
      }
    }

    throw new Error('تعذر استخراج بيانات الفاتورة حالياً. يرجى إدخال البيانات يدوياً.');
  }
}
