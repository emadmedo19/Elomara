import { 
  Building, Apartment, Payment, Expense, MaintenanceTicket, 
  FacilityBooking, Announcement, AppSettings, PaymentStatus 
} from '../types';
import { 
  initialBuildings, initialApartments, initialExpenses, 
  initialTickets, initialBookings, initialAnnouncements, initialPayments 
} from '../data/mockData';

const STORAGE_KEYS = {
  BUILDINGS: 'bunyan_buildings_v2',
  APARTMENTS: 'bunyan_apartments_v2',
  PAYMENTS: 'bunyan_payments_v2',
  EXPENSES: 'bunyan_expenses_v2',
  TICKETS: 'bunyan_tickets_v2',
  BOOKINGS: 'bunyan_bookings_v2',
  ANNOUNCEMENTS: 'bunyan_announcements_v2',
  ACTIVE_BUILDING: 'bunyan_active_building_id_v2',
  SETTINGS: 'bunyan_settings_v2',
};

// Safe localStorage wrapper
function load<T>(key: string, defaultValue: T): T {
  if (typeof window === 'undefined') return defaultValue;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Error loading ${key} from storage:`, e);
    return defaultValue;
  }
}

function save<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error saving ${key} to storage:`, e);
  }
}

// ---------------------- BUILDINGS ----------------------
export function getStoredBuildings(): Building[] {
  const data = load<Building[]>(STORAGE_KEYS.BUILDINGS, []);
  if (data.length === 0) {
    save(STORAGE_KEYS.BUILDINGS, initialBuildings);
    return initialBuildings;
  }
  return data;
}

export function saveStoredBuildings(buildings: Building[]): void {
  save(STORAGE_KEYS.BUILDINGS, buildings);
}

export function getActiveBuildingId(): string {
  const storedId = load<string>(STORAGE_KEYS.ACTIVE_BUILDING, '');
  const buildings = getStoredBuildings();
  if (storedId && buildings.some((b) => b.id === storedId)) {
    return storedId;
  }
  const defaultId = buildings[0]?.id || 'bld-1';
  save(STORAGE_KEYS.ACTIVE_BUILDING, defaultId);
  return defaultId;
}

export function setActiveBuildingId(buildingId: string): void {
  save(STORAGE_KEYS.ACTIVE_BUILDING, buildingId);
}

// ---------------------- APARTMENTS ----------------------
export function getStoredApartments(): Apartment[] {
  const data = load<Apartment[]>(STORAGE_KEYS.APARTMENTS, []);
  if (data.length === 0) {
    save(STORAGE_KEYS.APARTMENTS, initialApartments);
    return initialApartments;
  }
  return data;
}

export function saveStoredApartments(apartments: Apartment[]): void {
  save(STORAGE_KEYS.APARTMENTS, apartments);
}

// ---------------------- PAYMENTS ----------------------
export function getStoredPayments(): Payment[] {
  const data = load<Payment[]>(STORAGE_KEYS.PAYMENTS, []);
  if (data.length === 0) {
    save(STORAGE_KEYS.PAYMENTS, initialPayments);
    return initialPayments;
  }
  return data;
}

export function saveStoredPayments(payments: Payment[]): void {
  save(STORAGE_KEYS.PAYMENTS, payments);
}

// ---------------------- EXPENSES ----------------------
export function getStoredExpenses(): Expense[] {
  const data = load<Expense[]>(STORAGE_KEYS.EXPENSES, []);
  if (data.length === 0) {
    save(STORAGE_KEYS.EXPENSES, initialExpenses);
    return initialExpenses;
  }
  return data;
}

export function saveStoredExpenses(expenses: Expense[]): void {
  save(STORAGE_KEYS.EXPENSES, expenses);
}

// ---------------------- TICKETS ----------------------
export function getStoredTickets(): MaintenanceTicket[] {
  const data = load<MaintenanceTicket[]>(STORAGE_KEYS.TICKETS, []);
  if (data.length === 0) {
    save(STORAGE_KEYS.TICKETS, initialTickets);
    return initialTickets;
  }
  return data;
}

export function saveStoredTickets(tickets: MaintenanceTicket[]): void {
  save(STORAGE_KEYS.TICKETS, tickets);
}

// ---------------------- BOOKINGS ----------------------
export function getStoredBookings(): FacilityBooking[] {
  const data = load<FacilityBooking[]>(STORAGE_KEYS.BOOKINGS, []);
  if (data.length === 0) {
    save(STORAGE_KEYS.BOOKINGS, initialBookings);
    return initialBookings;
  }
  return data;
}

export function saveStoredBookings(bookings: FacilityBooking[]): void {
  save(STORAGE_KEYS.BOOKINGS, bookings);
}

// ---------------------- ANNOUNCEMENTS ----------------------
export function getStoredAnnouncements(): Announcement[] {
  const data = load<Announcement[]>(STORAGE_KEYS.ANNOUNCEMENTS, []);
  if (data.length === 0) {
    save(STORAGE_KEYS.ANNOUNCEMENTS, initialAnnouncements);
    return initialAnnouncements;
  }
  return data;
}

export function saveStoredAnnouncements(announcements: Announcement[]): void {
  save(STORAGE_KEYS.ANNOUNCEMENTS, announcements);
}

// ---------------------- SETTINGS ----------------------
export function getStoredSettings(): AppSettings {
  return load<AppSettings>(STORAGE_KEYS.SETTINGS, {
    customGeminiApiKey: '',
    backendUrl: '',
  });
}

export function saveStoredSettings(settings: AppSettings): void {
  save(STORAGE_KEYS.SETTINGS, settings);
}

// ---------------------- BACKUP & RESTORE ----------------------
export function exportDatabaseBackup(): string {
  const payload = {
    version: '2.0',
    exportedAt: new Date().toISOString(),
    buildings: getStoredBuildings(),
    apartments: getStoredApartments(),
    payments: getStoredPayments(),
    expenses: getStoredExpenses(),
    tickets: getStoredTickets(),
    bookings: getStoredBookings(),
    announcements: getStoredAnnouncements(),
    settings: getStoredSettings(),
  };
  return JSON.stringify(payload, null, 2);
}

export function importDatabaseBackup(jsonString: string): { success: boolean; message: string } {
  try {
    const data = JSON.parse(jsonString);
    if (!data.buildings || !Array.isArray(data.buildings) || data.buildings.length === 0) {
      return { success: false, message: 'ملف النسخة الاحتياطية غير صالح: لا يحتوي على بيانات عمارات.' };
    }

    if (data.buildings) saveStoredBuildings(data.buildings);
    if (data.apartments) saveStoredApartments(data.apartments);
    if (data.payments) saveStoredPayments(data.payments);
    if (data.expenses) saveStoredExpenses(data.expenses);
    if (data.tickets) saveStoredTickets(data.tickets);
    if (data.bookings) saveStoredBookings(data.bookings);
    if (data.announcements) saveStoredAnnouncements(data.announcements);
    if (data.settings) saveStoredSettings(data.settings);

    return { success: true, message: 'تمت استعادة كافة البيانات بنجاح!' };
  } catch (error: any) {
    return { success: false, message: `فشل استيراد الملف: ${error.message}` };
  }
}
