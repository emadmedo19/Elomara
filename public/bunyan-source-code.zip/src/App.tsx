import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building, UserRole, Apartment, Payment, Expense, MaintenanceTicket, 
  FacilityBooking, Announcement, AppSettings, PaymentStatus 
} from './types';
import { 
  getStoredBuildings, saveStoredBuildings, getActiveBuildingId, setActiveBuildingId,
  getStoredApartments, saveStoredApartments,
  getStoredPayments, saveStoredPayments,
  getStoredExpenses, saveStoredExpenses,
  getStoredTickets, saveStoredTickets,
  getStoredBookings, saveStoredBookings,
  getStoredAnnouncements, saveStoredAnnouncements,
  getStoredSettings, saveStoredSettings
} from './services/storage';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { CollectionsView } from './components/CollectionsView';
import { ExpensesView } from './components/ExpensesView';
import { ReportsView } from './components/ReportsView';
import { ResidentView } from './components/ResidentView';
import { AiChatView } from './components/AiChatView';
import { AiStudioView } from './components/AiStudioView';
import { PdfStatementModal } from './components/PdfStatementModal';
import { BuildingManagementModal } from './components/BuildingManagementModal';
import { SettingsModal } from './components/SettingsModal';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

export default function App() {
  // 1. Persistent State Initialization
  const [buildings, setBuildings] = useState<Building[]>(() => getStoredBuildings());
  const [currentBuildingId, setCurrentBuildingIdState] = useState<string>(() => getActiveBuildingId());
  const [role, setRole] = useState<UserRole>('manager');
  
  const [apartments, setApartments] = useState<Apartment[]>(() => getStoredApartments());
  const [payments, setPayments] = useState<Payment[]>(() => getStoredPayments());
  const [expenses, setExpenses] = useState<Expense[]>(() => getStoredExpenses());
  const [tickets, setTickets] = useState<MaintenanceTicket[]>(() => getStoredTickets());
  const [bookings, setBookings] = useState<FacilityBooking[]>(() => getStoredBookings());
  const [announcements, setAnnouncements] = useState<Announcement[]>(() => getStoredAnnouncements());
  const [settings, setSettings] = useState<AppSettings>(() => getStoredSettings());

  // 2. Active Building Resolver (Safe against deleted or missing IDs)
  const currentBuilding = useMemo(() => {
    return buildings.find((b) => b.id === currentBuildingId) || buildings[0] || {
      id: 'bld-fallback',
      name: 'عمارة سكنية',
      address: 'القاهرة، مصر',
      totalUnits: 0,
      balance: 0,
      monthlyTarget: 0,
      reserveFund: 0,
      managerName: 'المدير',
      managerPhone: '',
    };
  }, [buildings, currentBuildingId]);

  // 3. Navigation State (Defaults directly to 'dashboard')
  const [currentTab, setCurrentTabState] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab');
      if (tabParam && ['dashboard', 'collections', 'expenses', 'reports', 'resident', 'chat', 'image-studio'].includes(tabParam)) {
        return tabParam;
      }
    }
    return 'dashboard';
  });

  const setCurrentTab = (tab: string) => {
    setCurrentTabState(tab);
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.set('tab', tab);
      window.history.pushState({}, '', url.toString());
    }
  };

  const handleSelectBuilding = (b: Building) => {
    setCurrentBuildingIdState(b.id);
    setActiveBuildingId(b.id);
  };

  // 4. Modals State
  const [isBuildingModalOpen, setIsBuildingModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isAddExpenseModalOpen, setIsAddExpenseModalOpen] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  // 5. Toast System
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // 6. Android Hardware Back Button & Browser History Handling
  useEffect(() => {
    const handlePopState = () => {
      // If any modal is open, close modals first
      if (isBuildingModalOpen || isSettingsModalOpen || isAddExpenseModalOpen || isPdfModalOpen) {
        setIsBuildingModalOpen(false);
        setIsSettingsModalOpen(false);
        setIsAddExpenseModalOpen(false);
        setIsPdfModalOpen(false);
        return;
      }
      // If not on dashboard, return to dashboard
      if (currentTab !== 'dashboard') {
        setCurrentTabState('dashboard');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [isBuildingModalOpen, isSettingsModalOpen, isAddExpenseModalOpen, isPdfModalOpen, currentTab]);

  // 7. BUILDINGS CRUD
  const handleAddBuilding = (newBldData: Omit<Building, 'id'>) => {
    const newBld: Building = {
      ...newBldData,
      id: `bld-${Date.now()}`,
    };
    const updated = [...buildings, newBld];
    setBuildings(updated);
    saveStoredBuildings(updated);
    handleSelectBuilding(newBld);
    showToast(`تمت إضافة عمارة "${newBld.name}" بنجاح!`);
  };

  const handleUpdateBuilding = (id: string, updatedData: Partial<Building>) => {
    const updated = buildings.map((b) => (b.id === id ? { ...b, ...updatedData } : b));
    setBuildings(updated);
    saveStoredBuildings(updated);
    showToast('تم حفظ تعديلات بيانات العمارة بنجاح!');
  };

  const handleDeleteBuilding = (id: string) => {
    if (buildings.length <= 1) {
      showToast('لا يمكن حذف العمارة الوحيدة المتبقية في النظام.', 'error');
      return;
    }

    const bldToDelete = buildings.find((b) => b.id === id);
    const updatedBuildings = buildings.filter((b) => b.id !== id);
    setBuildings(updatedBuildings);
    saveStoredBuildings(updatedBuildings);

    // Clean up associated apartments, payments, and expenses to prevent orphaned records
    const updatedApartments = apartments.filter((a) => a.buildingId !== id);
    setApartments(updatedApartments);
    saveStoredApartments(updatedApartments);

    const updatedPayments = payments.filter((p) => p.buildingId !== id);
    setPayments(updatedPayments);
    saveStoredPayments(updatedPayments);

    const updatedExpenses = expenses.filter((e) => e.buildingId !== id);
    setExpenses(updatedExpenses);
    saveStoredExpenses(updatedExpenses);

    // If deleted building was active, switch to first available building
    if (currentBuildingId === id) {
      const nextBuilding = updatedBuildings[0];
      if (nextBuilding) {
        handleSelectBuilding(nextBuilding);
      }
    }

    showToast(`تم حذف عمارة "${bldToDelete?.name || ''}" وبياناتها المرتبطة بنجاح.`);
  };

  // 8. APARTMENTS CRUD
  const handleAddApartment = (newAptData: Omit<Apartment, 'id'>) => {
    const newApt: Apartment = {
      ...newAptData,
      id: `apt-${Date.now()}`,
      buildingId: currentBuilding.id,
    };
    const updated = [...apartments, newApt];
    setApartments(updated);
    saveStoredApartments(updated);

    // Update building totalUnits
    const updatedBuildings = buildings.map((b) =>
      b.id === currentBuilding.id ? { ...b, totalUnits: b.totalUnits + 1 } : b
    );
    setBuildings(updatedBuildings);
    saveStoredBuildings(updatedBuildings);

    showToast(`تمت إضافة ${newApt.unitNumber} باسم ${newApt.residentName} بنجاح!`);
  };

  const handleUpdateApartment = (id: string, updatedData: Partial<Apartment>) => {
    const updated = apartments.map((a) => (a.id === id ? { ...a, ...updatedData } : a));
    setApartments(updated);
    saveStoredApartments(updated);
    showToast('تم حفظ تعديل بيانات الشقة بنجاح!');
  };

  const handleDeleteApartment = (id: string) => {
    const aptToDelete = apartments.find((a) => a.id === id);
    const updatedApartments = apartments.filter((a) => a.id !== id);
    setApartments(updatedApartments);
    saveStoredApartments(updatedApartments);

    // Delete associated payments
    const updatedPayments = payments.filter((p) => p.apartmentId !== id);
    setPayments(updatedPayments);
    saveStoredPayments(updatedPayments);

    // Update building totalUnits
    const updatedBuildings = buildings.map((b) =>
      b.id === currentBuilding.id ? { ...b, totalUnits: Math.max(0, b.totalUnits - 1) } : b
    );
    setBuildings(updatedBuildings);
    saveStoredBuildings(updatedBuildings);

    showToast(`تم حذف ${aptToDelete?.unitNumber || 'الشقة'} وسجلاتها بنجاح.`);
  };

  // 9. PAYMENTS CRUD
  const handleSavePayment = (paymentData: {
    apartmentId: string;
    amount: number;
    date: string;
    month: string;
    method: Payment['method'];
    notes?: string;
    receiptNumber?: string;
  }) => {
    const apt = apartments.find((a) => a.id === paymentData.apartmentId);
    if (!apt) return;

    const newPayment: Payment = {
      ...paymentData,
      id: `pay-${Date.now()}`,
      buildingId: currentBuilding.id,
      unitNumber: apt.unitNumber,
      residentName: apt.residentName,
      recordedAt: new Date().toISOString(),
    };

    const updatedPayments = [newPayment, ...payments];
    setPayments(updatedPayments);
    saveStoredPayments(updatedPayments);

    // Recalculate Apartment Paid Amount & Status
    const newPaidAmount = (apt.paidAmount || 0) + paymentData.amount;
    const isNowPaidInFull = newPaidAmount >= apt.monthlyFee;
    const updatedApartments = apartments.map((a) => {
      if (a.id === apt.id) {
        return {
          ...a,
          paidAmount: newPaidAmount,
          status: isNowPaidInFull ? ('paid' as PaymentStatus) : a.status,
          overdueMonths: isNowPaidInFull ? 0 : a.overdueMonths,
          lastPaymentDate: paymentData.date,
        };
      }
      return a;
    });
    setApartments(updatedApartments);
    saveStoredApartments(updatedApartments);

    // Increase building treasury balance
    const updatedBuildings = buildings.map((b) =>
      b.id === currentBuilding.id ? { ...b, balance: b.balance + paymentData.amount } : b
    );
    setBuildings(updatedBuildings);
    saveStoredBuildings(updatedBuildings);

    showToast(`تم قيد سداد بمبلغ ${paymentData.amount.toLocaleString()} ج.م لـ ${apt.unitNumber} بنجاح!`);
  };

  const handleEditPayment = (updatedPayment: Payment) => {
    const oldPayment = payments.find((p) => p.id === updatedPayment.id);
    if (!oldPayment) return;

    const amountDiff = updatedPayment.amount - oldPayment.amount;

    // Update payments list
    const updatedPayments = payments.map((p) => (p.id === updatedPayment.id ? updatedPayment : p));
    setPayments(updatedPayments);
    saveStoredPayments(updatedPayments);

    // Recalculate apartment paidAmount
    const apt = apartments.find((a) => a.id === updatedPayment.apartmentId);
    if (apt) {
      const newPaidAmount = Math.max(0, (apt.paidAmount || 0) + amountDiff);
      const isNowPaidInFull = newPaidAmount >= apt.monthlyFee;
      const updatedApartments = apartments.map((a) => {
        if (a.id === apt.id) {
          return {
            ...a,
            paidAmount: newPaidAmount,
            status: isNowPaidInFull ? ('paid' as PaymentStatus) : a.status,
            lastPaymentDate: updatedPayment.date,
          };
        }
        return a;
      });
      setApartments(updatedApartments);
      saveStoredApartments(updatedApartments);
    }

    // Adjust building treasury balance
    if (amountDiff !== 0) {
      const updatedBuildings = buildings.map((b) =>
        b.id === currentBuilding.id ? { ...b, balance: b.balance + amountDiff } : b
      );
      setBuildings(updatedBuildings);
      saveStoredBuildings(updatedBuildings);
    }

    showToast('تم حفظ تعديلات الدفعة وإعادة تسوية الخزينة بنجاح!');
  };

  const handleDeletePayment = (paymentId: string) => {
    const pToDelete = payments.find((p) => p.id === paymentId);
    if (!pToDelete) return;

    const updatedPayments = payments.filter((p) => p.id !== paymentId);
    setPayments(updatedPayments);
    saveStoredPayments(updatedPayments);

    // Deduct from apartment paidAmount
    const apt = apartments.find((a) => a.id === pToDelete.apartmentId);
    if (apt) {
      const newPaidAmount = Math.max(0, (apt.paidAmount || 0) - pToDelete.amount);
      const updatedApartments = apartments.map((a) => {
        if (a.id === apt.id) {
          return {
            ...a,
            paidAmount: newPaidAmount,
            status: newPaidAmount >= a.monthlyFee ? 'paid' : newPaidAmount > 0 ? 'pending' : 'overdue',
          };
        }
        return a;
      });
      setApartments(updatedApartments);
      saveStoredApartments(updatedApartments);
    }

    // Deduct from building treasury balance
    const updatedBuildings = buildings.map((b) =>
      b.id === currentBuilding.id ? { ...b, balance: Math.max(0, b.balance - pToDelete.amount) } : b
    );
    setBuildings(updatedBuildings);
    saveStoredBuildings(updatedBuildings);

    showToast(`تم حذف الدفعة بمبلغ ${pToDelete.amount.toLocaleString()} ج.م وخصمها من الخزينة.`);
  };

  // 10. EXPENSES CRUD
  const handleAddExpense = (newExpData: Omit<Expense, 'id'>) => {
    const exp: Expense = {
      ...newExpData,
      id: `exp-${Date.now()}`,
      buildingId: currentBuilding.id,
    };
    const updated = [exp, ...expenses];
    setExpenses(updated);
    saveStoredExpenses(updated);

    // Deduct from building treasury balance
    const updatedBuildings = buildings.map((b) =>
      b.id === currentBuilding.id ? { ...b, balance: Math.max(0, b.balance - exp.amount) } : b
    );
    setBuildings(updatedBuildings);
    saveStoredBuildings(updatedBuildings);

    showToast(`تم توثيق مصروف "${exp.title}" بمبلغ ${exp.amount.toLocaleString()} ج.م وخصمه من الخزينة!`);
  };

  const handleUpdateExpense = (id: string, updatedData: Partial<Expense>) => {
    const oldExp = expenses.find((e) => e.id === id);
    if (!oldExp) return;

    const amountDiff = (updatedData.amount || oldExp.amount) - oldExp.amount;

    const updated = expenses.map((e) => (e.id === id ? { ...e, ...updatedData } : e));
    setExpenses(updated);
    saveStoredExpenses(updated);

    // Adjust building balance if amount changed
    if (amountDiff !== 0) {
      const updatedBuildings = buildings.map((b) =>
        b.id === currentBuilding.id ? { ...b, balance: Math.max(0, b.balance - amountDiff) } : b
      );
      setBuildings(updatedBuildings);
      saveStoredBuildings(updatedBuildings);
    }

    showToast('تم حفظ تعديل المصروف وتسوية الخزينة بنجاح!');
  };

  const handleDeleteExpense = (id: string) => {
    const expToDelete = expenses.find((e) => e.id === id);
    if (!expToDelete) return;

    const updated = expenses.filter((e) => e.id !== id);
    setExpenses(updated);
    saveStoredExpenses(updated);

    // Reimburse amount back to building treasury balance
    const updatedBuildings = buildings.map((b) =>
      b.id === currentBuilding.id ? { ...b, balance: b.balance + expToDelete.amount } : b
    );
    setBuildings(updatedBuildings);
    saveStoredBuildings(updatedBuildings);

    showToast(`تم حذف المصروف واسترجاع ${expToDelete.amount.toLocaleString()} ج.م لرصيد الخزينة.`);
  };

  // 11. TICKETS, BOOKINGS, ANNOUNCEMENTS
  const handleAddTicket = (newTkt: Omit<MaintenanceTicket, 'id'>) => {
    const tkt: MaintenanceTicket = {
      ...newTkt,
      id: `tkt-${Date.now()}`,
      buildingId: currentBuilding.id,
    };
    const updated = [tkt, ...tickets];
    setTickets(updated);
    saveStoredTickets(updated);
    showToast(`تم استلام بلاغ الصيانة بنجاح وإرساله للفني المختص.`);
  };

  const handleAddBooking = (newBk: Omit<FacilityBooking, 'id'>) => {
    const bk: FacilityBooking = {
      ...newBk,
      id: `bk-${Date.now()}`,
      buildingId: currentBuilding.id,
    };
    const updated = [bk, ...bookings];
    setBookings(updated);
    saveStoredBookings(updated);
    showToast(`تم تأكيد حجز ${newBk.facility} بتاريخ ${newBk.date}.`);
  };

  const handlePinAnnouncement = (newAnn: Omit<Announcement, 'id'>) => {
    const ann: Announcement = {
      ...newAnn,
      id: `ann-${Date.now()}`,
      buildingId: currentBuilding.id,
    };
    const updated = [ann, ...announcements];
    setAnnouncements(updated);
    saveStoredAnnouncements(updated);
    showToast('تم نشر الإعلان على لوحة تنبيهات العمارة بنجاح!');
  };

  // 12. SETTINGS
  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    saveStoredSettings(newSettings);
    showToast('تم حفظ إعدادات النظام ومفتاح Gemini بنجاح!');
  };

  const handleReloadAllStoredData = () => {
    setBuildings(getStoredBuildings());
    setCurrentBuildingIdState(getActiveBuildingId());
    setApartments(getStoredApartments());
    setPayments(getStoredPayments());
    setExpenses(getStoredExpenses());
    setTickets(getStoredTickets());
    setBookings(getStoredBookings());
    setAnnouncements(getStoredAnnouncements());
    setSettings(getStoredSettings());
    showToast('تمت استعادة كافة البيانات وتحديث الواجهة بنجاح!');
  };

  return (
    <div className="min-h-screen bg-[#0b1723] text-slate-800 flex flex-col items-center w-full">
      {/* Toast Notification Floating */}
      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#0f2537] text-white px-4 py-3 rounded-2xl shadow-2xl border border-teal-500/40 flex items-center gap-2.5 animate-in fade-in slide-in-from-top-3 text-xs max-w-md w-full">
          {toast.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          )}
          <span className="flex-1 font-medium">{toast.message}</span>
          <button onClick={() => setToast(null)} className="text-slate-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Container: Native full-width on mobile, max-w-7xl on desktop */}
      <div className="w-full flex flex-col min-h-screen bg-[#f8f9ff]">
        {/* Navigation & Header */}
        <Header
          buildings={buildings}
          currentBuilding={currentBuilding}
          onSelectBuilding={handleSelectBuilding}
          onOpenBuildingManagement={() => setIsBuildingModalOpen(true)}
          onOpenSettings={() => setIsSettingsModalOpen(true)}
          role={role}
          onSelectRole={(r) => {
            setRole(r);
            showToast(
              `تم التبديل إلى صفة: ${
                r === 'manager' ? 'مدير العمارة (أمين الصندوق)' : r === 'owner' ? 'مالك وحدة' : 'ساكن / مستأجر'
              }`,
              'info'
            );
          }}
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
        />

        {/* Content Body */}
        <main className="flex-1 p-3 sm:p-6 max-w-7xl mx-auto w-full">
          {currentTab === 'dashboard' && (
            <DashboardView
              building={currentBuilding}
              apartments={apartments.filter((a) => !a.buildingId || a.buildingId === currentBuilding.id)}
              expenses={expenses.filter((e) => !e.buildingId || e.buildingId === currentBuilding.id)}
              announcements={announcements.filter((a) => !a.buildingId || a.buildingId === currentBuilding.id)}
              tickets={tickets.filter((t) => !t.buildingId || t.buildingId === currentBuilding.id)}
              onNavigate={setCurrentTab}
              onOpenAddExpense={() => setIsAddExpenseModalOpen(true)}
              onOpenPdf={() => setIsPdfModalOpen(true)}
              onOpenAddPayment={() => setCurrentTab('collections')}
            />
          )}

          {currentTab === 'collections' && (
            <CollectionsView
              currentBuilding={currentBuilding}
              apartments={apartments}
              payments={payments}
              onAddApartment={handleAddApartment}
              onUpdateApartment={handleUpdateApartment}
              onDeleteApartment={handleDeleteApartment}
              onSavePayment={handleSavePayment}
              onEditPayment={handleEditPayment}
              onDeletePayment={handleDeletePayment}
            />
          )}

          {currentTab === 'expenses' && (
            <ExpensesView
              currentBuilding={currentBuilding}
              expenses={expenses}
              onAddExpense={handleAddExpense}
              onUpdateExpense={handleUpdateExpense}
              onDeleteExpense={handleDeleteExpense}
              isOpenAddModal={isAddExpenseModalOpen}
              onCloseAddModal={() => setIsAddExpenseModalOpen(false)}
              onOpenAddModal={() => setIsAddExpenseModalOpen(true)}
            />
          )}

          {currentTab === 'reports' && (
            <ReportsView
              building={currentBuilding}
              apartments={apartments.filter((a) => !a.buildingId || a.buildingId === currentBuilding.id)}
              expenses={expenses.filter((e) => !e.buildingId || e.buildingId === currentBuilding.id)}
              onOpenPdfModal={() => setIsPdfModalOpen(true)}
            />
          )}

          {currentTab === 'resident' && (
            <ResidentView
              building={currentBuilding}
              apartments={apartments.filter((a) => !a.buildingId || a.buildingId === currentBuilding.id)}
              tickets={tickets.filter((t) => !t.buildingId || t.buildingId === currentBuilding.id)}
              bookings={bookings.filter((b) => !b.buildingId || b.buildingId === currentBuilding.id)}
              onAddTicket={handleAddTicket}
              onAddBooking={handleAddBooking}
            />
          )}

          {currentTab === 'chat' && (
            <AiChatView buildingName={currentBuilding.name} />
          )}

          {currentTab === 'image-studio' && (
            <AiStudioView
              buildingName={currentBuilding.name}
              onPinAnnouncement={handlePinAnnouncement}
            />
          )}
        </main>

        {/* App Footer */}
        <footer className="bg-[#0f2537] text-slate-400 text-xs py-3.5 px-4 text-center border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>نظام بُنيان الذكي لإدارة العمارات السكنية © 2024</span>
          <div className="flex items-center gap-3 text-[11px] text-slate-300">
            <span>
              الخزينة المتاحة: <strong className="text-teal-300 font-bold">{currentBuilding.balance.toLocaleString()} ج.م</strong>
            </span>
            <span>•</span>
            <span>{currentBuilding.name}</span>
          </div>
        </footer>
      </div>

      {/* Building Management Modal */}
      <BuildingManagementModal
        isOpen={isBuildingModalOpen}
        onClose={() => setIsBuildingModalOpen(false)}
        buildings={buildings}
        currentBuilding={currentBuilding}
        onSelectBuilding={handleSelectBuilding}
        onAddBuilding={handleAddBuilding}
        onUpdateBuilding={handleUpdateBuilding}
        onDeleteBuilding={handleDeleteBuilding}
      />

      {/* Settings Modal (Building & App Preferences) */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        currentBuilding={currentBuilding}
      />

      {/* PDF Statement Modal */}
      {isPdfModalOpen && (
        <PdfStatementModal
          building={currentBuilding}
          apartments={apartments.filter((a) => !a.buildingId || a.buildingId === currentBuilding.id)}
          expenses={expenses.filter((e) => !e.buildingId || e.buildingId === currentBuilding.id)}
          onClose={() => setIsPdfModalOpen(false)}
        />
      )}
    </div>
  );
}
