import React, { useState } from 'react';
import { Apartment, Payment } from '../types';
import { 
  Building2, User, Phone, DollarSign, Calendar, CheckCircle2, 
  AlertCircle, Clock, Edit2, Trash2, Plus, MessageSquare, X, 
  Receipt, ArrowDownRight, Share2 
} from 'lucide-react';

interface ApartmentDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  apartment: Apartment | null;
  payments: Payment[];
  buildingName: string;
  onEditApartment: (apartment: Apartment) => void;
  onDeleteApartment: (apartmentId: string) => void;
  onOpenAddPaymentForApt: (apartment: Apartment) => void;
  onEditPayment: (payment: Payment) => void;
  onDeletePayment: (paymentId: string) => void;
}

export const ApartmentDetailsModal: React.FC<ApartmentDetailsModalProps> = ({
  isOpen,
  onClose,
  apartment,
  payments,
  buildingName,
  onEditApartment,
  onDeleteApartment,
  onOpenAddPaymentForApt,
  onEditPayment,
  onDeletePayment,
}) => {
  const [paymentToDelete, setPaymentToDelete] = useState<Payment | null>(null);
  const [isDeletingApartment, setIsDeletingApartment] = useState(false);

  if (!isOpen || !apartment) return null;

  const aptPayments = payments.filter((p) => p.apartmentId === apartment.id);
  const totalPaid = aptPayments.reduce((acc, p) => acc + p.amount, 0);
  const isPaidInFull = apartment.status === 'paid';

  const sendWhatsAppReceipt = () => {
    const text = encodeURIComponent(
      `السلام عليكم ${apartment.residentName} المحترم،\nتحية طيبة من اتحاد شاغلي ${buildingName}.\nموقف حساب ${apartment.unitNumber}:\n• قيمة الاشتراك الشهري: ${apartment.monthlyFee} ج.م\n• إجمالي المسدد: ${totalPaid.toLocaleString()} ج.م\n• الحالة الحالية: ${isPaidInFull ? 'خالص السداد ✓' : apartment.status === 'overdue' ? `متأخر (${apartment.overdueMonths} شهر)` : 'قيد الانتظار'}\nشكراً لتعاونكم وحرصكم على صيانة ونظافة العقار.`
    );
    window.open(`https://wa.me/${apartment.residentPhone.replace('+', '')}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0f2537]/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-4 sm:p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-sm">
              {apartment.unitNumber.slice(0, 4)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-slate-900">{apartment.unitNumber}</h3>
                <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full font-bold">
                  الدور {apartment.floor}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    apartment.isOwner
                      ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}
                >
                  {apartment.isOwner ? 'مالك وحدة' : 'مستأجر'}
                </span>
              </div>
              <p className="text-xs text-slate-500">{buildingName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Delete Apartment Confirmation */}
        {isDeletingApartment && (
          <div className="my-3.5 p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-3 animate-in fade-in">
            <div className="flex items-start gap-2.5 text-rose-900">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-sm">هل أنت متأكد من حذف {apartment.unitNumber}؟</strong>
                <p className="text-xs text-rose-700 leading-relaxed mt-1">
                  سيتم حذف الشقة وسجل السداد الخاص بها، وتحديث إجمالي وحدات العمارة تلقائياً.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                onClick={() => setIsDeletingApartment(false)}
                className="px-3.5 py-1.5 rounded-xl bg-white text-slate-700 text-xs font-bold border border-slate-200"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  onDeleteApartment(apartment.id);
                  onClose();
                }}
                className="px-4 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700"
              >
                تأكيد حذف الشقة
              </button>
            </div>
          </div>
        )}

        {/* Delete Payment Confirmation */}
        {paymentToDelete && (
          <div className="my-3.5 p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-2.5 animate-in fade-in">
            <div className="flex items-start gap-2.5 text-rose-900">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-sm">تأكيد حذف الدفعة المسجلة بمبلغ {paymentToDelete.amount.toLocaleString()} ج.م؟</strong>
                <p className="text-xs text-rose-700 text-[11px] mt-0.5">
                  سيتم خصم هذا المبلغ من رصيد الخزينة، وإعادة احتساب رصيد الشقة وحالتها.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                onClick={() => setPaymentToDelete(null)}
                className="px-3 py-1 rounded-xl bg-white text-slate-700 text-xs font-bold border border-slate-200"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  onDeletePayment(paymentToDelete.id);
                  setPaymentToDelete(null);
                }}
                className="px-3.5 py-1 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700"
              >
                حذف الدفعة
              </button>
            </div>
          </div>
        )}

        {/* Resident Summary Info Cards */}
        <div className="my-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
            <span className="text-[11px] text-slate-500 block">الشاغل الحالي</span>
            <span className="font-bold text-xs text-slate-900 block mt-0.5">{apartment.residentName}</span>
            <span className="text-[11px] text-slate-500 font-mono block mt-1 flex items-center gap-1">
              <Phone className="w-3 h-3 text-slate-400" />
              {apartment.residentPhone}
            </span>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
            <span className="text-[11px] text-slate-500 block">قيمة الاشتراك الشهري</span>
            <span className="font-bold text-sm text-teal-700 block mt-0.5">
              {apartment.monthlyFee.toLocaleString()} ج.م
            </span>
            <span className="text-[11px] text-slate-400 block mt-1">يستحق في اليوم الأول من كل شهر</span>
          </div>

          <div
            className={`p-3.5 rounded-2xl border ${
              apartment.status === 'paid'
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-800'
                : apartment.status === 'overdue'
                ? 'bg-rose-50/70 border-rose-200 text-rose-800'
                : 'bg-amber-50/70 border-amber-200 text-amber-800'
            }`}
          >
            <span className="text-[11px] block font-medium">حالة السداد الحالية</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              {apartment.status === 'paid' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
              {apartment.status === 'overdue' && <AlertCircle className="w-4 h-4 text-rose-600" />}
              {apartment.status === 'pending' && <Clock className="w-4 h-4 text-amber-600" />}
              <span className="font-bold text-xs">
                {apartment.status === 'paid' && 'خالص السداد بالكامل'}
                {apartment.status === 'overdue' && `متأخر (${apartment.overdueMonths} شهر)`}
                {apartment.status === 'pending' && 'قيد المتابعة / انتظار'}
              </span>
            </div>
            <span className="text-[11px] block mt-1">إجمالي المسدد: {totalPaid.toLocaleString()} ج.م</span>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenAddPaymentForApt(apartment)}
              className="bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 shadow-sm transition active:scale-95"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>تسجيل سداد جديد</span>
            </button>
            <button
              onClick={sendWhatsAppReceipt}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-2 rounded-xl flex items-center gap-1.5 transition active:scale-95"
              title="إرسال إشعار وكشف حساب عبر واتساب"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>إرسال واتساب</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onEditApartment(apartment)}
              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1 transition"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>تعديل الشقة</span>
            </button>
            <button
              onClick={() => setIsDeletingApartment(true)}
              className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 transition"
              title="حذف الشقة"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Payments History Ledger */}
        <div className="my-4 space-y-3 flex-1">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
              <Receipt className="w-4 h-4 text-teal-600" />
              <span>سجل المدفوعات والإيصالات السابقة ({aptPayments.length})</span>
            </h4>
            <span className="text-[11px] text-slate-500">
              المجموع: <strong className="text-teal-700 font-bold">{totalPaid.toLocaleString()} ج.م</strong>
            </span>
          </div>

          {aptPayments.length === 0 ? (
            <div className="text-center py-8 bg-slate-50 rounded-2xl border border-slate-200 text-slate-400 text-xs">
              لا توجد دفعات مسجلة لهذه الشقة بعد. اضغط "تسجيل سداد جديد" لقيد دفعة.
            </div>
          ) : (
            <div className="space-y-2 max-h-[35vh] overflow-y-auto pr-1">
              {aptPayments.map((p) => (
                <div
                  key={p.id}
                  className="p-3 bg-white rounded-2xl border border-slate-200 hover:border-teal-300 transition flex items-center justify-between gap-3 text-xs shadow-2xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">
                        {p.amount.toLocaleString()} ج.م
                      </span>
                      <span className="text-[10px] bg-teal-50 text-teal-700 font-bold px-2 py-0.5 rounded-full border border-teal-200">
                        {p.method}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {p.receiptNumber}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      <span>التاريخ: {p.date}</span>
                      <span>•</span>
                      <span>دورة: {p.month}</span>
                      {p.notes && <span>• {p.notes}</span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => onEditPayment(p)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-slate-100 transition"
                      title="تعديل بيانات الدفعة"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setPaymentToDelete(p)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                      title="حذف الدفعة"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
