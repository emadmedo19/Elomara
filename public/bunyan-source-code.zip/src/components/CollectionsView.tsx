import React, { useState } from 'react';
import { Building, Apartment, Payment, PaymentStatus } from '../types';
import { 
  Building2, Search, Filter, CheckCircle2, AlertCircle, Clock, 
  DollarSign, UserCheck, Phone, Plus, Edit2, Trash2, Eye, Share2, 
  ArrowUpRight, AlertTriangle, Check, X 
} from 'lucide-react';
import { ApartmentDetailsModal } from './ApartmentDetailsModal';
import { ApartmentFormModal } from './ApartmentFormModal';
import { PaymentModal } from './PaymentModal';

interface CollectionsViewProps {
  currentBuilding: Building;
  apartments: Apartment[];
  payments: Payment[];
  onAddApartment: (apartmentData: Omit<Apartment, 'id'>) => void;
  onUpdateApartment: (id: string, updatedData: Partial<Apartment>) => void;
  onDeleteApartment: (id: string) => void;
  onSavePayment: (paymentData: {
    apartmentId: string;
    amount: number;
    date: string;
    month: string;
    method: Payment['method'];
    notes?: string;
    receiptNumber?: string;
  }) => void;
  onEditPayment: (payment: Payment) => void;
  onDeletePayment: (paymentId: string) => void;
}

export const CollectionsView: React.FC<CollectionsViewProps> = ({
  currentBuilding,
  apartments,
  payments,
  onAddApartment,
  onUpdateApartment,
  onDeleteApartment,
  onSavePayment,
  onEditPayment,
  onDeletePayment,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [floorFilter, setFloorFilter] = useState<string>('all');

  // Modals state
  const [isAddAptModalOpen, setIsAddAptModalOpen] = useState(false);
  const [editingApartment, setEditingApartment] = useState<Apartment | null>(null);
  const [detailsApartment, setDetailsApartment] = useState<Apartment | null>(null);

  // Payment modal state
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedApartmentForPay, setSelectedApartmentForPay] = useState<Apartment | null>(null);
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);

  // Delete apartment confirmation
  const [apartmentToDelete, setApartmentToDelete] = useState<Apartment | null>(null);

  // Filter apartments by current building
  const buildingApartments = apartments.filter(
    (a) => !a.buildingId || a.buildingId === currentBuilding.id
  );

  const filteredApartments = buildingApartments.filter((apt) => {
    const matchesSearch =
      apt.unitNumber.includes(searchTerm) ||
      apt.residentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      apt.residentPhone.includes(searchTerm);

    const matchesStatus = statusFilter === 'all' || apt.status === statusFilter;
    const matchesFloor = floorFilter === 'all' || apt.floor.toString() === floorFilter;

    return matchesSearch && matchesStatus && matchesFloor;
  });

  // Calculate metrics
  const totalDuesExpected = buildingApartments.reduce((acc, a) => acc + a.monthlyFee, 0);
  const totalCollected = buildingApartments.reduce((acc, a) => acc + (a.paidAmount || 0), 0);
  const totalOverdue = buildingApartments
    .filter((a) => a.status === 'overdue')
    .reduce((acc, a) => acc + a.monthlyFee * Math.max(1, a.overdueMonths), 0);

  const paidCount = buildingApartments.filter((a) => a.status === 'paid').length;
  const overdueCount = buildingApartments.filter((a) => a.status === 'overdue').length;
  const pendingCount = buildingApartments.filter((a) => a.status === 'pending').length;

  // Handlers
  const handleOpenAddPayment = (apt?: Apartment) => {
    setSelectedApartmentForPay(apt || buildingApartments[0] || null);
    setEditingPayment(null);
    setIsPaymentModalOpen(true);
  };

  const handleOpenEditPayment = (p: Payment) => {
    setEditingPayment(p);
    setIsPaymentModalOpen(true);
  };

  const handleSaveApartmentForm = (data: {
    unitNumber: string;
    floor: number;
    residentName: string;
    residentPhone: string;
    isOwner: boolean;
    monthlyFee: number;
    status: PaymentStatus;
    overdueMonths: number;
  }) => {
    if (editingApartment) {
      onUpdateApartment(editingApartment.id, data);
      // Update details modal if open
      if (detailsApartment && detailsApartment.id === editingApartment.id) {
        setDetailsApartment({ ...detailsApartment, ...data });
      }
      setEditingApartment(null);
    } else {
      onAddApartment({
        ...data,
        buildingId: currentBuilding.id,
        paidAmount: data.status === 'paid' ? data.monthlyFee : 0,
        lastPaymentDate: data.status === 'paid' ? new Date().toISOString().split('T')[0] : undefined,
      });
      setIsAddAptModalOpen(false);
    }
  };

  const handleConfirmDeleteApartment = () => {
    if (apartmentToDelete) {
      onDeleteApartment(apartmentToDelete.id);
      if (detailsApartment && detailsApartment.id === apartmentToDelete.id) {
        setDetailsApartment(null);
      }
      setApartmentToDelete(null);
    }
  };

  const sendWhatsAppReceipt = (apt: Apartment) => {
    const text = encodeURIComponent(
      `السلام عليكم ${apt.residentName} المحترم،\nتحية طيبة من اتحاد شاغلي ${currentBuilding.name}.\nموقف حساب ${apt.unitNumber}:\n• قيمة الاشتراك: ${apt.monthlyFee} ج.م\n• إجمالي المسدد: ${(apt.paidAmount || 0).toLocaleString()} ج.م\n• الحالة: ${apt.status === 'paid' ? 'خالص السداد ✓' : apt.status === 'overdue' ? `متأخر (${apt.overdueMonths} شهر)` : 'قيد الانتظار'}\nشكراً لحرصكم على صيانة العقار.`
    );
    window.open(`https://wa.me/${apt.residentPhone.replace('+', '')}?text=${text}`, '_blank');
  };

  return (
    <div className="space-y-4">
      {/* Top Ledger Header & Summary Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-2xl bg-teal-50 text-teal-700">
              <Building2 className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold text-slate-900">سجل الشقق وسداد الاشتراكات</h1>
                <span className="text-xs bg-teal-50 text-teal-700 font-bold px-2.5 py-0.5 rounded-full border border-teal-200">
                  {currentBuilding.name}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                متابعة تحصيل الصيانة الدورية، إصدار إيصالات السداد، وتسجيل الاشتراكات
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => handleOpenAddPayment()}
            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition active:scale-95 shadow-sm"
          >
            <DollarSign className="w-4 h-4" />
            <span>تسجيل سداد</span>
          </button>

          <button
            onClick={() => {
              setEditingApartment(null);
              setIsAddAptModalOpen(true);
            }}
            className="bg-[#0f2537] hover:bg-[#1a3852] text-white text-xs font-bold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition active:scale-95 shadow-sm"
          >
            <Plus className="w-4 h-4 text-teal-300" />
            <span>إضافة شقة جديدة</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
          <span className="text-[11px] text-slate-500 block">المستهدف الشهري (إجمالي الشقق)</span>
          <span className="font-bold text-lg sm:text-xl text-slate-900 block mt-1">
            {totalDuesExpected.toLocaleString()} <span className="text-xs text-slate-500">ج.م</span>
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">{buildingApartments.length} شقة مسجلة</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
          <span className="text-[11px] text-emerald-600 block font-medium">إجمالي المحصل هذا الشهر</span>
          <span className="font-bold text-lg sm:text-xl text-emerald-700 block mt-1">
            {totalCollected.toLocaleString()} <span className="text-xs text-slate-500">ج.م</span>
          </span>
          <span className="text-[11px] text-emerald-600 block mt-1">{paidCount} شقة خالصة السداد ✓</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
          <span className="text-[11px] text-rose-600 block font-medium">متأخرات ومستحقات لم تُسدد</span>
          <span className="font-bold text-lg sm:text-xl text-rose-700 block mt-1">
            {totalOverdue.toLocaleString()} <span className="text-xs text-slate-500">ج.م</span>
          </span>
          <span className="text-[11px] text-rose-600 block mt-1">{overdueCount} شقة متأخرة</span>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
          <span className="text-[11px] text-amber-600 block font-medium">قيد الانتظار والمتابعة</span>
          <span className="font-bold text-lg sm:text-xl text-amber-700 block mt-1">
            {pendingCount} <span className="text-xs text-slate-500">شقة</span>
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">
            نسبة التحصيل: {totalDuesExpected > 0 ? Math.round((totalCollected / totalDuesExpected) * 100) : 0}%
          </span>
        </div>
      </div>

      {/* Delete Confirmation Alert Modal */}
      {apartmentToDelete && (
        <div className="fixed inset-0 z-50 bg-[#0f2537]/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-3">
            <div className="flex items-start gap-3 text-rose-900">
              <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-bold text-base">تأكيد حذف {apartmentToDelete.unitNumber}؟</h3>
                <p className="text-xs text-rose-700 leading-relaxed mt-1">
                  سيتم حذف الشقة المسجلة باسم "{apartmentToDelete.residentName}" نهائياً من سجلات العمارة، بما فيها سجل المدفوعات التابع لها.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setApartmentToDelete(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteApartment}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-sm"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Search and Filters Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث برقم الشقة، اسم الساكن، أو الهاتف..."
            className="w-full text-xs bg-slate-50 pr-8 pl-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto no-scrollbar text-xs">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none"
          >
            <option value="all">كل الحالات ({buildingApartments.length})</option>
            <option value="paid">خالص السداد ({paidCount})</option>
            <option value="overdue">متأخرات ({overdueCount})</option>
            <option value="pending">قيد الانتظار ({pendingCount})</option>
          </select>

          {/* Floor Filter */}
          <select
            value={floorFilter}
            onChange={(e) => setFloorFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none"
          >
            <option value="all">جميع الأدوار</option>
            <option value="1">الدور الأول</option>
            <option value="2">الدور الثاني</option>
            <option value="3">الدور الثالث</option>
            <option value="4">الدور الرابع</option>
            <option value="5">الدور الخامس</option>
            <option value="6">الروف / الدور السادس</option>
          </select>
        </div>
      </div>

      {/* Apartments Grid / Cards */}
      <div className="space-y-3">
        {filteredApartments.length === 0 ? (
          <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center text-slate-400 text-xs space-y-2">
            <Building2 className="w-8 h-8 text-slate-300 mx-auto" />
            <p>لا توجد شقق مطابقة للبحث أو الفلتر المختار.</p>
          </div>
        ) : (
          filteredApartments.map((apt) => {
            const isPaid = apt.status === 'paid';
            const isOverdue = apt.status === 'overdue';

            return (
              <div
                key={apt.id}
                className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs hover:shadow-sm transition flex flex-col md:flex-row md:items-center justify-between gap-3"
              >
                {/* Right Side: Unit, Resident Info */}
                <div className="flex items-start gap-3">
                  <div
                    className={`w-12 h-12 rounded-2xl flex flex-col items-center justify-center font-bold shrink-0 mt-0.5 shadow-2xs ${
                      isPaid
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : isOverdue
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    <span className="text-xs">{apt.unitNumber.replace('شقة ', '').replace('روف ', '')}</span>
                    <span className="text-[9px] font-normal opacity-80">د.{apt.floor}</span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-bold text-sm text-slate-900">{apt.unitNumber}</h3>
                      <span className="text-xs font-semibold text-slate-700">• {apt.residentName}</span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          apt.isOwner
                            ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {apt.isOwner ? 'مالك' : 'مستأجر'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1 font-mono text-[11px]">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {apt.residentPhone}
                      </span>
                      <span>•</span>
                      <span>الاشتراك: <strong className="text-slate-800">{apt.monthlyFee} ج.م</strong></span>
                      {apt.lastPaymentDate && (
                        <>
                          <span>•</span>
                          <span>آخر سداد: {apt.lastPaymentDate}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Left Side: Status & Actions */}
                <div className="flex flex-wrap items-center justify-between md:justify-end gap-2.5 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                  {/* Status Badge */}
                  <div className="flex items-center gap-1.5">
                    {isPaid && (
                      <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>خالص السداد ({apt.paidAmount || apt.monthlyFee} ج.م)</span>
                      </span>
                    )}
                    {isOverdue && (
                      <span className="bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>متأخر ({apt.overdueMonths} شهر)</span>
                      </span>
                    )}
                    {!isPaid && !isOverdue && (
                      <span className="bg-amber-50 text-amber-700 border border-amber-200 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>قيد الانتظار</span>
                      </span>
                    )}
                  </div>

                  {/* Actions buttons */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setDetailsApartment(apt)}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1 transition"
                      title="عرض كشف حساب وتفاصيل الشقة"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>تفاصيل</span>
                    </button>

                    <button
                      onClick={() => handleOpenAddPayment(apt)}
                      className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1 shadow-2xs transition active:scale-95"
                      title="قيد دفعة سداد جديدة لهذه الشقة"
                    >
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>سداد</span>
                    </button>

                    <button
                      onClick={() => {
                        setEditingApartment(apt);
                        setIsAddAptModalOpen(true);
                      }}
                      className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                      title="تعديل بيانات الشقة"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => setApartmentToDelete(apt)}
                      className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 transition"
                      title="حذف الشقة"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Apartment Modal */}
      {isAddAptModalOpen && (
        <ApartmentFormModal
          isOpen={isAddAptModalOpen}
          onClose={() => {
            setIsAddAptModalOpen(false);
            setEditingApartment(null);
          }}
          apartmentToEdit={editingApartment}
          buildingId={currentBuilding.id}
          onSave={handleSaveApartmentForm}
        />
      )}

      {/* Payment Recording / Editing Modal */}
      {isPaymentModalOpen && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => {
            setIsPaymentModalOpen(false);
            setSelectedApartmentForPay(null);
            setEditingPayment(null);
          }}
          apartments={buildingApartments}
          selectedApartment={selectedApartmentForPay}
          editingPayment={editingPayment}
          onSavePayment={(pData) => {
            if (editingPayment) {
              onEditPayment({
                ...editingPayment,
                ...pData,
              });
            } else {
              onSavePayment(pData);
            }
            setIsPaymentModalOpen(false);
          }}
          existingPayments={payments}
        />
      )}

      {/* Apartment Details & Payment History Modal */}
      {detailsApartment && (
        <ApartmentDetailsModal
          isOpen={!!detailsApartment}
          onClose={() => setDetailsApartment(null)}
          apartment={buildingApartments.find((a) => a.id === detailsApartment.id) || detailsApartment}
          payments={payments}
          buildingName={currentBuilding.name}
          onEditApartment={(apt) => {
            setEditingApartment(apt);
            setIsAddAptModalOpen(true);
          }}
          onDeleteApartment={(id) => {
            onDeleteApartment(id);
            setDetailsApartment(null);
          }}
          onOpenAddPaymentForApt={(apt) => handleOpenAddPayment(apt)}
          onEditPayment={(p) => handleOpenEditPayment(p)}
          onDeletePayment={(pId) => onDeletePayment(pId)}
        />
      )}
    </div>
  );
};
