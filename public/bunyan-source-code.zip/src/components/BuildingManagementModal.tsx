import React, { useState } from 'react';
import { Building } from '../types';
import { Building2, Plus, Edit2, Trash2, Check, X, AlertTriangle, ShieldCheck, Phone, MapPin, DollarSign } from 'lucide-react';

interface BuildingManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  buildings: Building[];
  currentBuilding: Building;
  onSelectBuilding: (building: Building) => void;
  onAddBuilding: (newBuilding: Omit<Building, 'id'>) => void;
  onUpdateBuilding: (id: string, updatedBuilding: Partial<Building>) => void;
  onDeleteBuilding: (id: string) => void;
}

export const BuildingManagementModal: React.FC<BuildingManagementModalProps> = ({
  isOpen,
  onClose,
  buildings,
  currentBuilding,
  onSelectBuilding,
  onAddBuilding,
  onUpdateBuilding,
  onDeleteBuilding,
}) => {
  const [mode, setMode] = useState<'list' | 'add' | 'edit'>('list');
  const [editingBuilding, setEditingBuilding] = useState<Building | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [totalUnits, setTotalUnits] = useState(10);
  const [balance, setBalance] = useState(0);
  const [monthlyTarget, setMonthlyTarget] = useState(15000);
  const [reserveFund, setReserveFund] = useState(20000);
  const [managerName, setManagerName] = useState('');
  const [managerPhone, setManagerPhone] = useState('');

  // Delete confirmation
  const [buildingToDelete, setBuildingToDelete] = useState<Building | null>(null);

  if (!isOpen) return null;

  const handleStartAdd = () => {
    setName('');
    setAddress('');
    setTotalUnits(10);
    setBalance(0);
    setMonthlyTarget(15000);
    setReserveFund(20000);
    setManagerName('');
    setManagerPhone('+2010');
    setMode('add');
  };

  const handleStartEdit = (b: Building) => {
    setEditingBuilding(b);
    setName(b.name);
    setAddress(b.address);
    setTotalUnits(b.totalUnits);
    setBalance(b.balance);
    setMonthlyTarget(b.monthlyTarget);
    setReserveFund(b.reserveFund);
    setManagerName(b.managerName);
    setManagerPhone(b.managerPhone);
    setMode('edit');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (mode === 'add') {
      onAddBuilding({
        name: name.trim(),
        address: address.trim() || 'القاهرة، مصر',
        totalUnits: Number(totalUnits) || 1,
        balance: Number(balance) || 0,
        monthlyTarget: Number(monthlyTarget) || 0,
        reserveFund: Number(reserveFund) || 0,
        managerName: managerName.trim() || 'مسؤول العقار',
        managerPhone: managerPhone.trim() || '+201000000000',
      });
      setMode('list');
    } else if (mode === 'edit' && editingBuilding) {
      onUpdateBuilding(editingBuilding.id, {
        name: name.trim(),
        address: address.trim(),
        totalUnits: Number(totalUnits),
        balance: Number(balance),
        monthlyTarget: Number(monthlyTarget),
        reserveFund: Number(reserveFund),
        managerName: managerName.trim(),
        managerPhone: managerPhone.trim(),
      });
      setMode('list');
    }
  };

  const handleConfirmDelete = () => {
    if (buildingToDelete) {
      onDeleteBuilding(buildingToDelete.id);
      setBuildingToDelete(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0f2537]/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full p-4 sm:p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {mode === 'list' && 'إدارة العمارات والمجمعات السكنية'}
                {mode === 'add' && 'إضافة عمارة سكنية جديدة'}
                {mode === 'edit' && `تعديل بيانات: ${editingBuilding?.name}`}
              </h2>
              <p className="text-xs text-slate-500">
                {mode === 'list' && 'إضافة أو تعديل أو تبديل أو حذف العمارات'}
                {mode === 'add' && 'سجل عمارة جديدة وحدد أهداف التحصيل ورصيد البداية'}
                {mode === 'edit' && 'تحديث الاسم والعنوان وبيانات الإدارة'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              if (mode !== 'list') setMode('list');
              else onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Delete Confirmation Alert */}
        {buildingToDelete && (
          <div className="my-4 p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-3 animate-in fade-in">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-sm text-rose-900">
                  تأكيد حذف عمارة "{buildingToDelete.name}"؟
                </h4>
                <p className="text-xs text-rose-700 leading-relaxed mt-1">
                  تحذير: هذا الإجراء سيقوم بحذف العمارة وجميع الشقق وسجلات التحصيل والمصروفات التابعة لها بشكل نهائي. لا يمكن التراجع عن هذا الإجراء.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setBuildingToDelete(null)}
                className="px-3.5 py-1.5 rounded-xl bg-white text-slate-700 text-xs font-bold border border-slate-300 hover:bg-slate-50"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 shadow-sm"
              >
                تأكيد الحذف النهائي
              </button>
            </div>
          </div>
        )}

        {/* Mode: List Buildings */}
        {mode === 'list' && (
          <div className="my-4 space-y-3 flex-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">
                العمارات المسجلة ({buildings.length})
              </span>
              <button
                onClick={handleStartAdd}
                className="bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-1.5 px-3 rounded-xl flex items-center gap-1.5 shadow-sm transition active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة عمارة جديدة</span>
              </button>
            </div>

            <div className="space-y-2.5 max-h-[50vh] overflow-y-auto pr-1">
              {buildings.map((b) => {
                const isActive = b.id === currentBuilding.id;
                return (
                  <div
                    key={b.id}
                    className={`p-3.5 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isActive
                        ? 'bg-teal-50/70 border-teal-300 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{b.name}</span>
                        {isActive && (
                          <span className="bg-teal-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                            العمارة النشطة
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          <span>{b.address}</span>
                        </span>
                        <span>•</span>
                        <span>{b.totalUnits} شقة</span>
                        <span>•</span>
                        <span>الخزينة: <strong className="text-teal-700">{b.balance.toLocaleString()} ج.م</strong></span>
                      </div>
                      <div className="text-[11px] text-slate-500">
                        المدير: {b.managerName} ({b.managerPhone})
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 self-end sm:self-center">
                      {!isActive && (
                        <button
                          onClick={() => {
                            onSelectBuilding(b);
                            onClose();
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-teal-600 hover:text-white text-slate-700 text-xs font-bold transition"
                        >
                          اختيار
                        </button>
                      )}
                      <button
                        onClick={() => handleStartEdit(b)}
                        className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                        title="تعديل بيانات العمارة"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      {buildings.length > 1 && (
                        <button
                          onClick={() => setBuildingToDelete(b)}
                          className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 transition"
                          title="حذف العمارة"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Mode: Add or Edit Form */}
        {(mode === 'add' || mode === 'edit') && (
          <form onSubmit={handleSubmit} className="my-4 space-y-3.5 flex-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1 sm:col-span-2">
                <label className="text-xs font-bold text-slate-700">اسم العمارة أو البرج *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: عمارة اللوتس 5"
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="text-xs font-bold text-slate-700">العنوان والموقع التفصيلي *</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="مثال: التجمع الخامس، الحي الأول، شارع التسعين"
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">عدد الشقق والوحدات</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={totalUnits}
                  onChange={(e) => setTotalUnits(Number(e.target.value))}
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">رصيد الخزينة الحالي (ج.م)</label>
                <input
                  type="number"
                  value={balance}
                  onChange={(e) => setBalance(Number(e.target.value))}
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">المستهدف الشهري للتحصيل (ج.م)</label>
                <input
                  type="number"
                  value={monthlyTarget}
                  onChange={(e) => setMonthlyTarget(Number(e.target.value))}
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">صندوق الطوارئ والاحتياطي (ج.م)</label>
                <input
                  type="number"
                  value={reserveFund}
                  onChange={(e) => setReserveFund(Number(e.target.value))}
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">اسم مدير العمارة / أمين الصندوق</label>
                <input
                  type="text"
                  value={managerName}
                  onChange={(e) => setManagerName(e.target.value)}
                  placeholder="مثال: م/ أحمد فؤاد"
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">رقم هاتف المدير / واتساب</label>
                <input
                  type="text"
                  value={managerPhone}
                  onChange={(e) => setManagerPhone(e.target.value)}
                  placeholder="+201000000000"
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setMode('list')}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md transition active:scale-95 flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{mode === 'add' ? 'إضافة العمارة الآن' : 'حفظ التعديلات'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Footer */}
        {mode === 'list' && (
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
            >
              إغلاق
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
