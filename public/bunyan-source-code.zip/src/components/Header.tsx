import React from 'react';
import { Building, UserRole } from '../types';
import { 
  Building2, ChevronDown, ShieldCheck, User, Sparkles, 
  Settings, Plus, SlidersHorizontal 
} from 'lucide-react';

interface HeaderProps {
  buildings: Building[];
  currentBuilding: Building;
  onSelectBuilding: (b: Building) => void;
  onOpenBuildingManagement: () => void;
  onOpenSettings: () => void;
  role: UserRole;
  onSelectRole: (r: UserRole) => void;
  currentTab: string;
  onSelectTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  buildings,
  currentBuilding,
  onSelectBuilding,
  onOpenBuildingManagement,
  onOpenSettings,
  role,
  onSelectRole,
  currentTab,
  onSelectTab,
}) => {
  return (
    <header className="bg-[#0f2537] text-white border-b border-slate-700/60 sticky top-0 z-40 shadow-lg">
      {/* Top Utility & Brand Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2">
        {/* Brand identity */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-br from-teal-500 to-[#00668b] flex items-center justify-center font-bold text-lg sm:text-xl text-white shadow-md shadow-teal-900/30 ring-1 ring-white/20">
            بُ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base sm:text-lg tracking-tight text-white flex items-center gap-1.5">
                بُنيان
                <span className="text-[10px] bg-teal-500/20 text-teal-300 border border-teal-500/30 px-2 py-0.5 rounded-full font-medium">
                  منظومة إدارة العمارات
                </span>
              </span>
            </div>
            <p className="text-[11px] text-slate-300 hidden sm:block">
              {currentBuilding.name} • {currentBuilding.address}
            </p>
          </div>
        </div>

        {/* Building Selector & Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Building Selector Dropdown */}
          <div className="relative">
            <select
              value={currentBuilding.id}
              onChange={(e) => {
                const found = buildings.find((b) => b.id === e.target.value);
                if (found) onSelectBuilding(found);
              }}
              className="bg-white/10 hover:bg-white/15 text-white text-xs font-semibold py-1.5 px-3 pr-2 pl-7 rounded-xl border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 cursor-pointer appearance-none text-right transition"
            >
              {buildings.map((b) => (
                <option key={b.id} value={b.id} className="text-slate-900 bg-white">
                  🏢 {b.name} ({b.totalUnits} شقة)
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-300 absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Building Management Modal Trigger */}
          <button
            onClick={onOpenBuildingManagement}
            className="p-1.5 px-2.5 rounded-xl bg-teal-600/30 hover:bg-teal-600/50 text-teal-300 border border-teal-500/40 text-xs font-bold transition flex items-center gap-1"
            title="إدارة العمارات (إضافة، تعديل، حذف)"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span className="hidden md:inline">إدارة العمارات</span>
          </button>

          {/* Role Switcher */}
          <div className="hidden sm:flex items-center bg-white/10 p-0.5 rounded-xl border border-white/15 text-[11px]">
            <button
              onClick={() => onSelectRole('manager')}
              className={`px-2 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                role === 'manager'
                  ? 'bg-teal-500 text-white font-bold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="مدير العمارة وأمين الصندوق"
            >
              <ShieldCheck className="w-3 h-3" />
              <span className="hidden lg:inline">أمين الصندوق</span>
            </button>
            <button
              onClick={() => onSelectRole('owner')}
              className={`px-2 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                role === 'owner'
                  ? 'bg-teal-500 text-white font-bold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="مالك شقة"
            >
              <Building2 className="w-3 h-3" />
              <span className="hidden lg:inline">مالك</span>
            </button>
            <button
              onClick={() => onSelectRole('resident')}
              className={`px-2 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                role === 'resident'
                  ? 'bg-teal-500 text-white font-bold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="ساكن أو مستأجر"
            >
              <User className="w-3 h-3" />
              <span className="hidden lg:inline">ساكن</span>
            </button>
          </div>

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 border border-white/15 transition"
            title="إعدادات التطبيق وتفضيلات العمارة"
          >
            <Settings className="w-4 h-4 text-slate-300" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="bg-[#0b1c30] px-3 sm:px-6 overflow-x-auto no-scrollbar border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center gap-1 py-1.5 text-xs whitespace-nowrap">
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`px-3 py-1.5 rounded-xl font-medium transition flex items-center gap-1.5 ${
              currentTab === 'dashboard'
                ? 'bg-teal-600/30 text-teal-300 border border-teal-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <span>🏛️</span>
            <span>لوحة التحكم</span>
          </button>

          <button
            onClick={() => onSelectTab('collections')}
            className={`px-3 py-1.5 rounded-xl font-medium transition flex items-center gap-1.5 ${
              currentTab === 'collections'
                ? 'bg-teal-600/30 text-teal-300 border border-teal-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <span>🏢</span>
            <span>سجل الشقق والتحصيل</span>
          </button>

          <button
            onClick={() => onSelectTab('expenses')}
            className={`px-3 py-1.5 rounded-xl font-medium transition flex items-center gap-1.5 ${
              currentTab === 'expenses'
                ? 'bg-teal-600/30 text-teal-300 border border-teal-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <span>🧾</span>
            <span>المصروفات والفواتير</span>
          </button>

          <button
            onClick={() => onSelectTab('reports')}
            className={`px-3 py-1.5 rounded-xl font-medium transition flex items-center gap-1.5 ${
              currentTab === 'reports'
                ? 'bg-teal-600/30 text-teal-300 border border-teal-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <span>📊</span>
            <span>التقارير وكشف الحساب</span>
          </button>

          <button
            onClick={() => onSelectTab('resident')}
            className={`px-3 py-1.5 rounded-xl font-medium transition flex items-center gap-1.5 ${
              currentTab === 'resident'
                ? 'bg-teal-600/30 text-teal-300 border border-teal-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <span>🔑</span>
            <span>بوابة الساكن والمرافق</span>
          </button>

          <button
            onClick={() => onSelectTab('chat')}
            className={`px-3 py-1.5 rounded-xl font-medium transition flex items-center gap-1.5 ${
              currentTab === 'chat'
                ? 'bg-indigo-600/40 text-indigo-300 border border-indigo-400/50 font-bold shadow-sm'
                : 'text-indigo-300 hover:text-white hover:bg-indigo-500/10'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-300" />
            <span className="font-bold">المساعد الذكي Gemini</span>
          </button>

          <button
            onClick={() => onSelectTab('image-studio')}
            className={`px-3 py-1.5 rounded-xl font-medium transition flex items-center gap-1.5 ${
              currentTab === 'image-studio'
                ? 'bg-amber-600/30 text-amber-300 border border-amber-400/40 font-bold'
                : 'text-amber-300/80 hover:text-amber-200 hover:bg-amber-500/10'
            }`}
          >
            <span>🎨</span>
            <span>إعلانات ولوحات العمارة</span>
          </button>
        </div>
      </div>
    </header>
  );
};
