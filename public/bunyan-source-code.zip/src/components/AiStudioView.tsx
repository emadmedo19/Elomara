import React, { useState } from 'react';
import { Announcement } from '../types';
import { 
  Sparkles, Image as ImageIcon, Wand2, Download, Pin, 
  RefreshCw, Check, AlertCircle, Layers, Palette
} from 'lucide-react';

interface AiStudioViewProps {
  buildingName: string;
  onPinAnnouncement: (announcement: Omit<Announcement, 'id'>) => void;
}

export const AiStudioView: React.FC<AiStudioViewProps> = ({
  buildingName,
  onPinAnnouncement,
}) => {
  const [mode, setMode] = useState<'create' | 'edit'>('create');
  const [prompt, setPrompt] = useState(
    'تصميم لوحة إعلان رسمية أنيقة لعمارة سكنية: تنبيه موعد الصيانة الدورية للمصعد غداً الأربعاء، ألوان كحلية وذهبية فاخرة، خط عربي واضح'
  );
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [selectedModel, setSelectedModel] = useState<'gemini-nano-banana-2.1' | 'gemini-3.1-flash-lite-image'>('gemini-nano-banana-2.1');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Edit state
  const [editPrompt, setEditPrompt] = useState('أضف شريطاً ذهبياً في الأعلى مع كلمة "تنبيه هام وعاجل"');
  const [isEditing, setIsEditing] = useState(false);

  // Pinned state feedback
  const [isPinned, setIsPinned] = useState(false);

  // Pre-set building templates
  const templates = [
    {
      title: 'صيانة المصعد الدورية',
      prompt: 'تصميم لوحة إعلان رسمية فاخرة: تنبيه بموعد الصيانة الدورية لمصعد عمارة سكنية راقية، أيقونة مصعد، ألوان كحلية وبيضاء راقية مع شريط تحذيري ذهبي',
      aspectRatio: '1:1',
    },
    {
      title: 'نظافة المداخل والممرات',
      prompt: 'ملصق توعوي وإرشادي لنظافة مدخل عمارة سكنية وممرات السلالم، أسلوب عصري أنيق، تصميم احترافي بألوان خضراء وكحلية هادئة',
      aspectRatio: '3:4',
    },
    {
      title: 'تنظيم مواقف السيارات بالجراج',
      prompt: 'لوحة إرشادية لموقف سيارات عمارة سكنية: الالتزام بالأماكن المخصصة لكل شقة وعدم الوقوف في الممرات، تصميم حديث واضح',
      aspectRatio: '16:9',
    },
    {
      title: 'دعوة الجمعية العمومية للملاك',
      prompt: 'تصميم بطاقة دعوة رسمية فاخرة لحضور اجتماع الجمعية العمومية السنوية لاتحاد شاغلي العقار، طابع مؤسسي مميز',
      aspectRatio: '1:1',
    },
  ];

  const handleGenerate = async (customPrompt?: string) => {
    const text = customPrompt || prompt;
    if (!text.trim() || isGenerating) return;

    setIsGenerating(true);
    setErrorMessage(null);
    setIsPinned(false);

    try {
      const response = await fetch('/api/gemini/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `${text} - Residential building HOA management in Egypt, high resolution professional architectural graphics`,
          aspectRatio,
          model: selectedModel,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'فشل في توليد الصورة');
      }

      const data = await response.json();
      if (data.imageUrl) {
        setGeneratedImageUrl(data.imageUrl);
      } else {
        throw new Error('لم يتم استلام رابط الصورة');
      }
    } catch (err: any) {
      console.error('Image generation error:', err);
      setErrorMessage(err.message || 'حدث خطأ أثناء الاتصال بنموذج توليد الصور');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEdit = async () => {
    if (!generatedImageUrl || !editPrompt.trim() || isEditing) return;

    setIsEditing(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/gemini/edit-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: editPrompt,
          base64Image: generatedImageUrl,
          mimeType: 'image/png',
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'فشل في تعديل الصورة');
      }

      const data = await response.json();
      if (data.imageUrl) {
        setGeneratedImageUrl(data.imageUrl);
      } else {
        throw new Error('لم يتم استلام الصورة المعدلة');
      }
    } catch (err: any) {
      console.error('Image edit error:', err);
      setErrorMessage(err.message || 'حدث خطأ أثناء تعديل الصورة');
    } finally {
      setIsEditing(false);
    }
  };

  const handlePinToBoard = () => {
    if (!generatedImageUrl) return;

    onPinAnnouncement({
      title: 'إعلان مصور جديد من إدارة العمارة',
      content: prompt,
      date: new Date().toISOString().split('T')[0],
      type: 'general',
      imageUrl: generatedImageUrl,
      pinned: true,
    });

    setIsPinned(true);
    setTimeout(() => setIsPinned(false), 3000);
  };

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="bg-gradient-to-l from-[#0f2537] via-[#1a3852] to-[#00668b] p-5 rounded-2xl text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-500/30">
              <Wand2 className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold">استوديو إعلانات ولوحات العمارة الذكي</h1>
                <span className="text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full font-bold">
                  {selectedModel}
                </span>
              </div>
              <p className="text-xs text-slate-200 mt-0.5">
                توليد ملصقات وإعلانات صيانة العقار وتعديلها بنصوص الأوامر بواسطة Gemini
              </p>
            </div>
          </div>
        </div>

        {/* Model Switcher */}
        <div className="flex items-center gap-2 bg-white/10 p-1.5 rounded-xl border border-white/15 text-xs">
          <span className="text-slate-300 text-[11px] pr-1">النموذج:</span>
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value as any)}
            className="bg-transparent text-white font-bold text-xs focus:outline-none cursor-pointer"
          >
            <option value="gemini-nano-banana-2.1" className="text-slate-900 bg-white">
              gemini-nano-banana-2.1 (دقة عالية)
            </option>
            <option value="gemini-3.1-flash-lite-image" className="text-slate-900 bg-white">
              gemini-3.1-flash-lite-image (سريع)
            </option>
          </select>
        </div>
      </div>

      {/* Main Two-Column Studio Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Prompting & Configuration */}
        <div className="lg:col-span-5 space-y-4">
          {/* Creation Mode Switcher */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
            <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-bold">
              <button
                onClick={() => setMode('create')}
                className={`flex-1 py-2 rounded-lg transition flex items-center justify-center gap-1.5 ${
                  mode === 'create' ? 'bg-[#0f2537] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-teal-300" />
                <span>توليد إعلان جديد</span>
              </button>
              <button
                onClick={() => setMode('edit')}
                disabled={!generatedImageUrl}
                className={`flex-1 py-2 rounded-lg transition flex items-center justify-center gap-1.5 disabled:opacity-40 ${
                  mode === 'edit' ? 'bg-[#0f2537] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                <Wand2 className="w-3.5 h-3.5 text-amber-300" />
                <span>تعديل الصورة الحالية</span>
              </button>
            </div>

            {mode === 'create' ? (
              <div className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-800 font-bold mb-1.5">
                    وصف الإعلان أو الملصق المطلوب:
                  </label>
                  <textarea
                    rows={4}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="اكتب وصف الإعلان المطلوب بدقة..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition"
                  />
                </div>

                {/* Aspect Ratio Selector */}
                <div>
                  <label className="block text-slate-800 font-bold mb-1.5">
                    أبعاد اللوحة (Aspect Ratio):
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { label: '1:1 مربع', value: '1:1' },
                      { label: '16:9 شاشات', value: '16:9' },
                      { label: '3:4 ملصق', value: '3:4' },
                      { label: '9:16 ستوري', value: '9:16' },
                    ].map((item) => (
                      <button
                        key={item.value}
                        type="button"
                        onClick={() => setAspectRatio(item.value)}
                        className={`py-2 px-1 text-center rounded-xl border text-[11px] font-bold transition ${
                          aspectRatio === item.value
                            ? 'bg-[#0f2537] text-white border-[#0f2537] shadow-xs'
                            : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Template Chips */}
                <div>
                  <span className="text-[11px] font-bold text-slate-500 block mb-1.5">
                    نماذج إعلانات جاهزة للاختيار السريع:
                  </span>
                  <div className="space-y-1.5">
                    {templates.map((tpl, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          setPrompt(tpl.prompt);
                          setAspectRatio(tpl.aspectRatio);
                        }}
                        className="w-full text-right p-2.5 rounded-xl bg-slate-50 hover:bg-teal-50 hover:text-teal-900 border border-slate-200 hover:border-teal-300 transition text-xs flex items-center justify-between"
                      >
                        <span className="font-semibold text-slate-800">{tpl.title}</span>
                        <span className="text-[10px] bg-slate-200/80 px-2 py-0.5 rounded text-slate-600">
                          {tpl.aspectRatio}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleGenerate()}
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full bg-[#0f2537] hover:bg-[#1a3852] disabled:opacity-50 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 shadow-md transition active:scale-95 text-xs"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-teal-300" />
                      <span>جاري توليد التصميم بواسطة {selectedModel}...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-teal-300" />
                      <span>توليد لوحة الإعلان الآن</span>
                    </>
                  )}
                </button>
              </div>
            ) : (
              /* Edit Mode */
              <div className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-800 font-bold mb-1.5">
                    أمر التعديل على التصميم الحالي:
                  </label>
                  <textarea
                    rows={3}
                    value={editPrompt}
                    onChange={(e) => setEditPrompt(e.target.value)}
                    placeholder="اكتب التعديلات المطلوبة (مثال: أضف ختم معتمد باللون الأخضر، غير لون الخط...)"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleEdit}
                  disabled={isEditing || !editPrompt.trim()}
                  className="w-full bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 shadow-md transition active:scale-95 text-xs"
                >
                  {isEditing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري تطبيق التعديل الذكي...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-4 h-4" />
                      <span>تطبيق التعديل على الإعلان</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Visual Preview Canvas */}
        <div className="lg:col-span-7">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col items-center justify-center min-h-[480px]">
            {generatedImageUrl ? (
              <div className="w-full flex flex-col items-center">
                <div className="relative group max-w-md w-full rounded-2xl overflow-hidden border border-slate-200 shadow-lg bg-slate-900">
                  <img
                    src={generatedImageUrl}
                    alt="Generated building poster"
                    className="w-full h-auto object-contain max-h-[500px]"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-3 p-4">
                    <a
                      href={generatedImageUrl}
                      download={`bonyan-announcement-${Date.now()}.png`}
                      className="bg-white text-slate-900 px-3.5 py-2 rounded-xl font-bold text-xs shadow-lg hover:bg-slate-100 flex items-center gap-1.5 transition"
                    >
                      <Download className="w-4 h-4 text-teal-600" />
                      <span>تنزيل الصورة</span>
                    </a>
                  </div>
                </div>

                {/* Operations Bar for Generated Image */}
                <div className="flex flex-wrap items-center justify-center gap-2.5 mt-4 w-full">
                  <button
                    onClick={handlePinToBoard}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition active:scale-95 ${
                      isPinned
                        ? 'bg-emerald-600 text-white'
                        : 'bg-teal-600 hover:bg-teal-700 text-white'
                    }`}
                  >
                    {isPinned ? <Check className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
                    <span>{isPinned ? 'تم النشر بلوحة الإعلانات ✓' : 'نشر على لوحة إعلانات العمارة'}</span>
                  </button>

                  <a
                    href={generatedImageUrl}
                    download={`bonyan-announcement-${Date.now()}.png`}
                    className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center gap-1.5 transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>حفظ الصورة بجهازك</span>
                  </a>

                  <button
                    onClick={() => {
                      setMode('edit');
                    }}
                    className="px-4 py-2.5 rounded-xl text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1.5 transition"
                  >
                    <Wand2 className="w-4 h-4 text-amber-600" />
                    <span>تعديل هذا التصميم</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center p-8 max-w-sm">
                <div className="w-16 h-16 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-3 shadow-inner">
                  <ImageIcon className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-sm text-slate-800 mb-1">معاينة الإعلان المصمم</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  اختر أحد النماذج المقترحة أو اكتب وصفاً مخصصاً، واضغط «توليد لوحة الإعلان» ليقوم Gemini بإنتاج بوستر احترافي عالي الدقة.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
