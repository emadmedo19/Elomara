import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.bunyan.residential',
  appName: 'بُنيان',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
